﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CDN_iTaas
{
    class ConverCDN
    {
        private string data1L1;
        public string Data1L1
        {
            get { return this.data1L1; }
            set { this.data1L1 = value; }
        }

        private string data2L1;
        public string Data2L1
        {
            get { return this.data2L1; }
            set { this.data2L1 = value; }
        }

        private string data3L1;
        public string Data3L1
        {
            get { return this.data3L1; }
            set { this.data3L1 = value; }
        }

        private string data5L1;
        public string Data5L1
        {
            get { return this.data5L1; }
            set { this.data5L1 = value; }
        }

        private string data6L1;
        public string Data6L1
        {
            get { return this.data6L1; }
            set { this.data6L1 = value; }
        }


        private string data7L1;
        public string Data7L1
        {
            get { return this.data7L1; }
            set { this.data7L1 = value; }
        }

        private string data11L1;
        public string Data11L1
        {
            get { return this.data11L1; }
            set { this.data11L1 = value; }
        }

        private string[] line1Charac;
        public string[] Line1Charac
        {
            get { return this.line1Charac; }
            set { this.line1Charac = value; }
        }


        private string wordLine1;
        public string WordLine1
        {
            get { return this.wordLine1; }
            set { this.wordLine1 = value; }
        }

        private int counter1;
        public int Counter1
        {
            get { return this.counter1; }
            set { this.counter1 = value; }
        }


       





    }
}
