﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace CDN_iTaas
{
    class DataCDN
    {

        private string line1;
        public string Line1
        {
            get { return this.line1; }
            set { this.line1 = value; }
        }

        private string line2;
        public string Line2
        {
            get { return this.line2; }
            set { this.line2 = value; }
        }

        private string line3;
        public string Line3
        {
            get { return this.line3; }
            set { this.line3 = value; }
        }

        private string line4;
        public string Line4
        {
            get { return this.line4; }
            set { this.line4 = value; }
        }

        private int counter;
        public int Counter
        {
            get { return this.counter; }
            set { this.counter = value; }
        }


        private string[] l1C;
        public string[] L1C
        {
            get { return this.l1C; }
            set { this.l1C = value; }
        }


        private string[] l2C;
        public string[] L2C
        {
            get { return this.l2C; }
            set { this.l2C = value; }
        }

        private string[] l3C;
        public string[] L3C
        {
            get { return this.l3C; }
            set { this.l3C = value; }
        }


        private string[] l4C;
        public string[] L4C
        {
            get { return this.l4C; }
            set { this.l4C = value; }
        }


        private string urlW;
        public string UrlW
        {
            get { return this.urlW; }
            set { this.urlW = value; }
        }



        private bool test1;
        public bool Test1
        {
            get { return this.test1; }
            set { this.test1 = value; }
        }








    }
}
