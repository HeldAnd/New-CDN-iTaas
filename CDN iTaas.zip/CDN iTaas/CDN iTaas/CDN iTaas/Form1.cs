﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CDN_iTaas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // CLASS DataCDN
            DataCDN btd = new DataCDN();
            AgoraFT url = new AgoraFT();

            btd.UrlW = urlBox2.Text;

            //----------------------------------------------------------

            //CHECK THE TEXT BOX
            btd.Test1 = false;

            while (btd.Test1 == false)
            {
                if (!btd.UrlW.StartsWith("https://"))
                {
                    MessageBox.Show("Please, informe the addres https://........");
                    btd.Test1 = true;
                }
                else if (!btd.UrlW.EndsWith(".txt"))
                {
                    MessageBox.Show("Please, ends the the addres with: .txt");
                    btd.Test1 = true;
                }
                else
                {
                    break;

                }

            }
            //----------------------------------------------------------------------


            try
            {
                
                StreamReader reader = new StreamReader(WebRequest.Create(urlBox2.Text).GetResponse().GetResponseStream());
                
                while (true)
                {

                    url.UrlR = reader.ReadLine();
                    if (url.UrlR != null)
                    {
                        
                        btd.Counter++;
                    }
                    else
                    {
                        
                        break;
                    }

                

                    // Write each line in each string

                    if (btd.Counter == 1)
                    {
                        btd.Line1 = url.UrlR;
                        //MessageBox.Show("Linha 1: "+ btd.Line1);

                    }
                    else if (btd.Counter == 2)
                    {
                        btd.Line2 = url.UrlR;
                        //MessageBox.Show("Linha 2: "+ btd.Line2);

                    }

                    else if (btd.Counter == 3)
                    {
                        btd.Line3 = url.UrlR;
                        //MessageBox.Show("Linha 3: "+ btd.Line3);

                    }

                    else if (btd.Counter == 4)
                    {
                        btd.Line4 = url.UrlR;
                        //MessageBox.Show("Linha 4: "+ btd.Line4);


                    }

                }

                reader.Close();

            }

            // In case of problem

            catch (Exception q)
            {
                Console.WriteLine("The link could not be read:");
                Console.WriteLine(q.Message);
            }

            //------------------------------------------------------------------------
            //------------------------------------------------------------------------


            // SPLIT DA LINHA 1

            // CLASS ConverCDN
            ConverCDN cl1 = new ConverCDN();


            // Split1

            while (cl1.Counter1 <= 11 && btd.Test1 == false)
            {

                btd.L1C = btd.Line1.Split(' ', '|', '.', '"');

                foreach (var wordl1 in btd.L1C)
                {
                    cl1.WordLine1 = wordl1;                   
                    cl1.Counter1++;                    

                    // WRITE EACH WORD IN DIFFERENT MEMORY
                    if (cl1.Counter1 == 1)
                    {
                        cl1.Data1L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 1 Line 1: " + cl1.Data1L1);
                    }
                    else if (cl1.Counter1 == 2)
                    {
                        cl1.Data2L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 2 Line 1: " + cl1.Data2L1);
                    }

                    else if (cl1.Counter1 == 3)
                    {
                        cl1.Data3L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 3 Line 1: " + cl1.Data3L1);
                    }

                    else if (cl1.Counter1 == 5)
                    {
                        cl1.Data5L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 5 Line 1: " + cl1.Data5L1);
                    }

                    else if (cl1.Counter1 == 6)
                    {
                        cl1.Data6L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 6 Line 1: " + cl1.Data6L1);
                    }

                    else if (cl1.Counter1 == 7)
                    {
                        cl1.Data7L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 7 Line 1: " + cl1.Data7L1);
                    }

                    else if (cl1.Counter1 == 11)
                    {
                        cl1.Data11L1 = cl1.WordLine1;
                        //MessageBox.Show("Word 11 Line 1: " + cl1.Data11L1);
                    }

                }

            }


            //------------------------------------------------------------------------

            // Agora format Line 1

            AgoraFT aft = new AgoraFT();

            aft.FirstL1 = "\"Minha CDN\"";
            aft.DAgL1 = aft.FirstL1 + (' ') + cl1.Data5L1 + (' ') + cl1.Data2L1 + (' ') + cl1.Data6L1 + ('.') + cl1.Data7L1 + (' ') + cl1.Data11L1 + (' ') + cl1.Data1L1 + (' ') + cl1.Data3L1;
            //MessageBox.Show("Agora Line 1: " + aft.DAgL1);


            //------------------------------------------------------------------------


            //------------------------------------------------------------------------
            //------------------------------------------------------------------------


            // SPLIT DA LINHA 2

            // CLASS ConverCDN
            ConversL2 cl2 = new ConversL2();


            // Split2

            while (cl2.Counter2 <= 11 && btd.Test1 == false)
            {
                btd.L2C = btd.Line2.Split(' ', '|', '.', '"');
                foreach (var wordl2 in btd.L2C)
                {
                    cl2.WordLine2 = wordl2;
                    cl2.Counter2++;

                    // WRITE EACH WORD IN DIFFERENT MEMORY
                    if (cl2.Counter2 == 1)
                    {
                        cl2.Data1L2 = cl2.WordLine2;
                        //MessageBox.Show("Word 1 Line 2: " + cl2.Data1L2);
                    }
                    else if (cl2.Counter2 == 2)
                    {
                        cl2.Data2L2 = cl2.WordLine2;
                        //MessageBox.Show("Word 2 Line 2: " + cl2.Data2L2);
                    }

                    else if (cl2.Counter2 == 3)
                    {
                        cl2.Data3L2 = cl2.WordLine2;
                        //MessageBox.Show("Word 3 Line 2: " + cl2.Data3L2);
                    }

                    else if (cl2.Counter2 == 5)
                    {
                        cl2.Data5L2 = cl2.WordLine2;
                        //MessageBox.Show("Word 5 Line 2: " + cl2.Data5L2);
                    }

                    else if (cl2.Counter2 == 6)
                    {
                        cl2.Data6L2 = cl2.WordLine2;
                        //MessageBox.Show("Word 6 Line 2: " + cl2.Data6L2);
                    }

                    else if (cl2.Counter2 == 10)
                    {
                        cl2.Data10L2 = cl2.WordLine2;
                        //MessageBox.Show("Word 7 Line 2: " + cl2.Data10L2);
                    }

                   




                }

            }


            //------------------------------------------------------------------------

            // Agora format Line 2

            AgoraFT aft2 = new AgoraFT();

            aft2.FirstL2 = "\"Minha CDN\"";
            aft2.DAgL2 = aft2.FirstL2 + (' ') + cl2.Data5L2 + (' ') + cl2.Data2L2 + (' ') + cl2.Data6L2 + (' ') + cl2.Data10L2 + (' ') + cl2.Data1L2 + (' ') + cl2.Data3L2;
            //MessageBox.Show("Agora Line 2: " + aft2.DAgL2);


            //------------------------------------------------------------------------


            //------------------------------------------------------------------------
            //------------------------------------------------------------------------

            // SPLIT DA LINHA 3

            // CLASS ConverCDN
            ConversL3 cl3 = new ConversL3();


            // Split3

            while (cl3.Counter3 <= 11 && btd.Test1 == false)
            {
                btd.L3C = btd.Line3.Split(' ', '|', '.', '"');
                foreach (var wordl3 in btd.L3C)
                {
                    cl3.WordLine3 = wordl3;
                    cl3.Counter3++;

                    // WRITE EACH WORD IN DIFFERENT MEMORY
                    if (cl3.Counter3 == 1)
                    {
                        cl3.Data1L3 = cl3.WordLine3;
                        //MessageBox.Show("Word 1 Line 3: " + cl3.Data1L3);
                    }
                    else if (cl3.Counter3 == 2)
                    {
                        cl3.Data2L3 = cl3.WordLine3;
                        //MessageBox.Show("Word 2 Line 3: " + cl3.Data2L3);
                    }

                    else if (cl3.Counter3 == 3)
                    {
                        cl3.Data3L3 = cl3.WordLine3;
                        //MessageBox.Show("Word 3 Line 3: " + cl3.Data3L3);
                    }

                    else if (cl3.Counter3 == 5)
                    {
                        cl3.Data5L3 = cl3.WordLine3;
                        //MessageBox.Show("Word 5 Line 3: " + cl3.Data5L3);
                    }

                    else if (cl3.Counter3 == 6)
                    {
                        cl3.Data6L3 = cl3.WordLine3;
                        //MessageBox.Show("Word 6 Line 3: " + cl3.Data6L3);
                    }

                    else if (cl3.Counter3 == 10)
                    {
                        cl3.Data10L3 = cl3.WordLine3;
                        cl3.Cal = Convert.ToUInt16(cl3.Data10L3);
                        //MessageBox.Show("Word 7 Line 3: " + cl3.Data10L3);
                        //MessageBox.Show("The number is: " + cl3.Cal);
                    }

                    else if (cl3.Counter3 == 11)
                    {
                        cl3.Data11L3 = cl3.WordLine3;
                        //MessageBox.Show("Word 11 Line 3: " + cl3.Data11L3);
                        cl3.Cal9 = Convert.ToUInt16(cl3.Data11L3);
                        //MessageBox.Show("The number is: " + cl3.Cal9);
                    }




                }


                if (cl3.Cal9 == 9)
                {
                    
                    int Cal2 = cl3.Cal + 1;
                    cl3.Data10L3 = Convert.ToString(Cal2);
                    //MessageBox.Show(cl3.Data10L3);

                }

            }


            //------------------------------------------------------------------------

            // Agora format Line 3

            AgoraFT aft3 = new AgoraFT();

            aft3.FirstL3 = "\"Minha CDN\"";
            aft3.DAgL3 = aft3.FirstL3 + (' ') + cl3.Data5L3 + (' ') + cl3.Data2L3 + (' ') + cl3.Data6L3 + (' ') + cl3.Data10L3 + (' ') + cl3.Data1L3 + (' ') + cl3.Data3L3;
            //MessageBox.Show("Agora Line 3: " + aft3.DAgL3);


            //------------------------------------------------------------------------


            //------------------------------------------------------------------------
            //------------------------------------------------------------------------


            // SPLIT DA LINHA 4

            // CLASS ConverCDN
            ConversL4 cl4 = new ConversL4();


            // Split4

            while (cl4.Counter4 <= 11 && btd.Test1 == false)
            {
                btd.L4C = btd.Line4.Split(' ', '|', '.', '"');
                foreach (var word4 in btd.L4C)
                {
                    cl4.WordLine4 = word4;
                    cl4.Counter4++;

                    // WRITE EACH WORD IN DIFFERENT MEMORY
                    if (cl4.Counter4 == 1)
                    {
                        cl4.Data1L4 = cl4.WordLine4;
                        //MessageBox.Show("Word 1 Line 4: " + cl4.Data1L4);
                    }
                    else if (cl4.Counter4 == 2)
                    {
                        cl4.Data2L4 = cl4.WordLine4;
                        //MessageBox.Show("Word 2 Line 4: " + cl4.Data2L4);
                    }

                    else if (cl4.Counter4 == 3)
                    {
                        cl4.Data3L4 = "REFRESH_HIT";
                        //MessageBox.Show("Word 3 Line 4: " + cl4.Data3L4);
                    }

                    else if (cl4.Counter4 == 5)
                    {
                        cl4.Data5L4 = cl4.WordLine4;
                        //MessageBox.Show("Word 5 Line 4: " + cl4.Data5L4);
                    }

                    else if (cl4.Counter4 == 6)
                    {
                        cl4.Data6L4 = cl4.WordLine4;
                        //MessageBox.Show("Word 6 Line 4: " + cl4.Data6L4);
                    }

                    else if (cl4.Counter4 == 7)
                    {
                        cl4.Data7L4 = cl4.WordLine4;
                        //MessageBox.Show("Word 7 Line 4: " + cl4.Data7L4);
                    }

                    else if (cl4.Counter4 == 11)
                    {
                        cl4.Data11L4 = cl4.WordLine4;
                        //MessageBox.Show("Word 11 Line 4: " + cl4.Data11L4);
                    }

                }

            }


            //------------------------------------------------------------------------

            // Agora format Line 4

            AgoraFT aft4 = new AgoraFT();

            aft4.FirstL4 = "\"Minha CDN\"";
            aft4.DAgL4 = aft4.FirstL4 + (' ') + cl4.Data5L4 + (' ') + cl4.Data2L4 + (' ') + cl4.Data6L4 + ('.') + cl4.Data7L4 + (' ') + cl4.Data11L4 + (' ') + cl4.Data1L4 + (' ') + cl4.Data3L4;
            //MessageBox.Show("Agora Line 4: " + aft4.DAgL4);


            //------------------------------------------------------------------------


            //------------------------------------------------------------------------
            //------------------------------------------------------------------------

            // AGORA FORMAT

            while (btd.Test1 == false)
                {
                AgoraFT aft5 = new AgoraFT();
               

                aft5.DateT = DateTime.Now;

                aft5.HeaderL1 = "#Version: 1.0";
                aft5.HeaderL2 = "#Date: ";
                aft5.HeaderL3 = "#Fields: provider http-method status-code uri-path time-taken";
                aft5.HeaderL4 = "response-size cache-status";
                aft5.AgoraF = aft5.HeaderL1 + ('\n') + aft5.HeaderL2 + aft5.DateT + ('\n') + aft5.HeaderL3 + ('\n') + aft5.HeaderL4 + ('\n') + aft.DAgL1 + ('\n') + aft2.DAgL2 + ('\n') + aft3.DAgL3 + ('\n') + aft4.DAgL4;
                MessageBox.Show("The conversion was: " + ('\n') + aft5.AgoraF);

                //------------------------------------------------------------------------
                //------------------------------------------------------------------------

                FileData fd = new FileData();

                fd.FileName = fileBox.Text;
                fd.TargetPath = @"C:\Users\Public";

                //----------------------------------------------------------

                fd.Test2 = false;

                while (fd.Test2 == false)
                {
                    if (fd.FileName.Equals(value: null))
                    {
                        MessageBox.Show("Please, informe the file name: convert http://.........txt");
                        fd.Test2 = true;
                    }
                    else if (!fd.FileName.EndsWith(".txt"))
                    {
                        MessageBox.Show("Please, ends the file name with: .txt");
                        fd.Test2 = true;

                    }
                    else
                    {
                        break;

                    }

                }
                //----------------------------------------------------------------------


                while (fd.Test2 == false)
                {
                    

                    

                    fd.DestFile = System.IO.Path.Combine(fd.TargetPath, fd.FileName);
                    MessageBox.Show("The destiny file is: " + ('\n') + fd.DestFile);



                    if (!File.Exists(fd.DestFile))
                    {

                        File.WriteAllText(fd.DestFile, aft5.AgoraF);
                        string readText = File.ReadAllText(fd.DestFile);
                        MessageBox.Show("The Text in the file is: " + ('\n') + readText);
                        fd.Test2 = true;



                    }
                    else
                    {
                        MessageBox.Show("Please, choose another File Name.");
                        fd.Test2 = true;
                    }

                }

                //------------------------------------------------------------------------
                //------------------------------------------------------------------------







                btd.Test1 = true;
            }

            //------------------------------------------------------------------------
            //------------------------------------------------------------------------

            


           





        }

        private void urlBox2_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
