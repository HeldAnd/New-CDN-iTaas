﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDN_iTaas
{
    class ConversL4
    {

        private string data1L4;
        public string Data1L4
        {
            get { return this.data1L4; }
            set { this.data1L4 = value; }
        }

        private string data2L4;
        public string Data2L4
        {
            get { return this.data2L4; }
            set { this.data2L4 = value; }
        }

        private string data3L4;
        public string Data3L4
        {
            get { return this.data3L4; }
            set { this.data3L4 = value; }
        }

        private string data5L4;
        public string Data5L4
        {
            get { return this.data5L4; }
            set { this.data5L4 = value; }
        }

        private string data6L4;
        public string Data6L4
        {
            get { return this.data6L4; }
            set { this.data6L4 = value; }
        }


        private string data7L4;
        public string Data7L4
        {
            get { return this.data7L4; }
            set { this.data7L4 = value; }
        }

        private string data11L4;
        public string Data11L4
        {
            get { return this.data11L4; }
            set { this.data11L4 = value; }
        }

        private string[] line4Charac;
        public string[] Line4Charac
        {
            get { return this.line4Charac; }
            set { this.line4Charac = value; }
        }


        private string wordLine4;
        public string WordLine4
        {
            get { return this.wordLine4; }
            set { this.wordLine4 = value; }
        }

        private int counter4;
        public int Counter4
        {
            get { return this.counter4; }
            set { this.counter4 = value; }
        }

        



    }
}
