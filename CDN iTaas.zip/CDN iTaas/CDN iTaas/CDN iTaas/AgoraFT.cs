﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDN_iTaas
{
    class AgoraFT
    {
        private string dAgL1;
        public string DAgL1
        {
            get { return this.dAgL1; }
            set { this.dAgL1 = value; }
        }

        private string firstL1;
        public string FirstL1
        {
            get { return this.firstL1; }
            set { this.firstL1 = value; }
        }

        //----------------------------------------------------------------

        private string dAgL2;
        public string DAgL2
        {
            get { return this.dAgL2; }
            set { this.dAgL2 = value; }
        }

        private string firstL2;
        public string FirstL2
        {
            get { return this.firstL2; }
            set { this.firstL2 = value; }
        }

        //----------------------------------------------------------------

        private string dAgL3;
        public string DAgL3
        {
            get { return this.dAgL3; }
            set { this.dAgL3 = value; }
        }

        private string firstL3;
        public string FirstL3
        {
            get { return this.firstL3; }
            set { this.firstL3 = value; }

        }

        //----------------------------------------------------------------

        private string dAgL4;
        public string DAgL4
        {
            get { return this.dAgL4; }
            set { this.dAgL4 = value; }
        }


        private string firstL4;
        public string FirstL4
        {
            get { return this.firstL4; }
            set { this.firstL4 = value; }
        }


        //----------------------------------------------------------------


        private string agoraF;
        public string AgoraF
        {
            get { return this.agoraF; }
            set { this.agoraF = value; }
        }


        //----------------------------------------------------------------


        private string headerL1;
        public string HeaderL1
        {
            get { return this.headerL1; }
            set { this.headerL1 = value; }
        }

        //----------------------------------------------------------------


        private string headerL2;
        public string HeaderL2
        {
            get { return this.headerL2; }
            set { this.headerL2 = value; }
        }

        //----------------------------------------------------------------

        private string headerL3;
        public string HeaderL3
        {
            get { return this.headerL3; }
            set { this.headerL3 = value; }
        }

        //----------------------------------------------------------------


        private string headerL4;
        public string HeaderL4
        {
            get { return this.headerL4; }
            set { this.headerL4 = value; }
        }

        //----------------------------------------------------------------


        private string urlR;
        public string UrlR
        {
            get { return this.urlR; }
            set { this.urlR = value; }
        }

        //----------------------------------------------------------------


        private DateTime dateT;
        public DateTime DateT
        {
            get { return this.dateT; }
            set { this.dateT = value; }
        }


    }
}
