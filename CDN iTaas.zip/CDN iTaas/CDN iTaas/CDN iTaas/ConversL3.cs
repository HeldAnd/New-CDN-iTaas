﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDN_iTaas
{
    class ConversL3
    {
        private string data1L3;
        public string Data1L3
        {
            get { return this.data1L3; }
            set { this.data1L3 = value; }
        }

        private string data2L3;
        public string Data2L3
        {
            get { return this.data2L3; }
            set { this.data2L3 = value; }
        }

        private string data3L3;
        public string Data3L3
        {
            get { return this.data3L3; }
            set { this.data3L3 = value; }
        }

        private string data5L3;
        public string Data5L3
        {
            get { return this.data5L3; }
            set { this.data5L3 = value; }
        }

        private string data6L3;
        public string Data6L3
        {
            get { return this.data6L3; }
            set { this.data6L3 = value; }
        }


        private string data10L3;
        public string Data10L3
        {
            get { return this.data10L3; }
            set { this.data10L3 = value; }
        }

        private string data11L3;
        public string Data11L3
        {
            get { return this.data11L3; }
            set { this.data11L3 = value; }
        }


        private int cal;
        public int Cal
        {
            get { return this.cal; }
            set { this.cal = value; }
        }

        private int cal9;
        public int Cal9
        {
            get { return this.cal9; }
            set { this.cal9 = value; }
        }

        private string[] line3Charac;
        public string[] Line3Charac
        {
            get { return this.line3Charac; }
            set { this.line3Charac = value; }
        }


        private string wordLine3;
        public string WordLine3
        {
            get { return this.wordLine3; }
            set { this.wordLine3 = value; }
        }

        private int counter3;
        public int Counter3
        {
            get { return this.counter3; }
            set { this.counter3 = value; }
        }

       



    }
}
