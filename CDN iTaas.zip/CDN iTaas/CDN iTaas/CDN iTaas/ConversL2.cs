﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDN_iTaas
{
    class ConversL2
    {

        private string data1L2;
        public string Data1L2
        {
            get { return this.data1L2; }
            set { this.data1L2 = value; }
        }

        private string data2L2;
        public string Data2L2
        {
            get { return this.data2L2; }
            set { this.data2L2 = value; }
        }

        private string data3L2;
        public string Data3L2
        {
            get { return this.data3L2; }
            set { this.data3L2 = value; }
        }

        private string data5L2;
        public string Data5L2
        {
            get { return this.data5L2; }
            set { this.data5L2 = value; }
        }

        private string data6L2;
        public string Data6L2
        {
            get { return this.data6L2; }
            set { this.data6L2 = value; }
        }


        private string data10L2;
        public string Data10L2
        {
            get { return this.data10L2; }
            set { this.data10L2 = value; }
        }


        private string[] line2Charac;
        public string[] Line2Charac
        {
            get { return this.line2Charac; }
            set { this.line2Charac = value; }
        }


        private string wordLine2;
        public string WordLine2
        {
            get { return this.wordLine2; }
            set { this.wordLine2 = value; }
        }

        private int counter2;
        public int Counter2
        {
            get { return this.counter2; }
            set { this.counter2 = value; }
        }

       





    }
}
