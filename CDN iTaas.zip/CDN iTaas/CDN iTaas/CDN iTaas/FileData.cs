﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDN_iTaas
{
    class FileData
    {
        private string fileName;
        public string FileName
        {
            get { return this.fileName; }
            set { this.fileName = value; }
        }

        private string targetPath = @"C:\Users\Public";
        public string TargetPath
        {
            get { return this.targetPath; }
            set { this.targetPath = value; }
        }


        // Path class 
        private string destFile;
        public string DestFile
        {
            get { return this.destFile; }
            set { this.destFile = value; }
        }


        private bool test2;
        public bool Test2
        {
            get { return this.test2; }
            set { this.test2 = value; }
        }



    }
}
